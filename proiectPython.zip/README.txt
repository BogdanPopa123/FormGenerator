Form Generator - aceasta aplicatie este un generator de documente tipizate PDF.
Pentru a genera un formular trebuie preluat un fisier .docx sau .txt din sistem, iar datele
ce trebuie inlocuite vor fi marcate cu ________ (underscore) (exemplu: "In data de ____ s a intamplat ____").
Aplicatia numara cate grupari de forma _______________ exista in document iar pentru fiecare grupare apare
un text-field, continutul acestora inlocuind ______.

Am folosit Flask pentru partea de web, iar pentru partea de prelucrare text docx2pdf, fpdf, pdfgen

Popa Bogdan - Codul de python

Fromea Dragos - Codul de css

Duminica Ana - Codul de html

Dificultati: numarul de text fields nu era cel la care ne asteptam, am rezolvat acest lucru prin debug cu printf uri